<?php 
phpinfo();
 ?>